<h1 align="center">BVAI v1.0</h1>
<p align="center">
      A new facebook account cracker tool for termux users
</p>

## 馃攳 ***About BVAI***:

BVAI is a python based script. You can use this tool for crack facebook users EMAIL passwords. This tool works on both rooted Android device and Non-rooted Android device.

## All commands for install this tool
$ pkg update && pkg upgrade
<br>
$ pkg install python
<br/>
$ pkg install python2
<br/>
$ pkg install git
<br/>
$ pkg install wget
<br/>
$ pkg install php
<br/>
$ pkg install openssh
<br/>
$ git clone https://github.com/botolmehedi/bvai
<br/>
$ pip2 install requests
<br/>
$ pip2 install mechanize
<br/>
$ ls
<br/>
$ cd bvai
<br/>
$ python2 bvai.py
<br/>
...
<br/>
• TOOL USER : (knock me on facebook)
<br/>
• TOOL PASS : (knock me on facebook)
<br/>
....
<br/>

* Note:- Don't try to edit or modify this tool.

## 馃敆 ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/MasterTrick1

### Chekout our webite:
https://www.mastertrick.design

## 馃懃 ***Join***

### Facebook group: 
https://www.facebook.com/groups/231747098048450

### Telegram channel:
https://t.me/mastertrick2

### Facebook page:
https://www.facebook.com/TeamVVirus

### Instagram: 
https://www.instagram.com/MehtanOfficial

### My GitHub ID link:
https://www.github.com/BotolMehedi

### 馃摙 Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
